"""Spark setup and data analysis for COVID-19 dashboard."""
import os
import urllib.request
import logging
from pathlib import Path

import findspark
from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import DoubleType
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.regression import LinearRegression

from . import config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def setup_spark():
    """Initialize findspark (honors SPARK_HOME) and return a SparkSession.

    This sets a few environment variables early so the JVM is started with
    the required options on newer JDKs and PySpark workers use the same
    Python interpreter as the driver.
    """
    # Ensure Java / PySpark options are set before JVM startup
    import sys

    # Use the running Python executable for PySpark workers
    py_exec = sys.executable
    os.environ.setdefault("PYSPARK_PYTHON", py_exec)
    os.environ.setdefault("PYSPARK_DRIVER_PYTHON", py_exec)

    # Add the Java system property to disable subject credential behavior
    # which causes getSubject() to throw in some JDKs. Avoid using
    # --add-opens here as it caused the JVM to reject JAVA_TOOL_OPTIONS
    # on some Windows setups.
    jopts = os.environ.get("JAVA_TOOL_OPTIONS", "")
    extra_props = "-Djavax.security.auth.useSubjectCredsOnly=false"
    if extra_props not in jopts:
        os.environ["JAVA_TOOL_OPTIONS"] = (jopts + " " + extra_props).strip()

    # On Windows, HADOOP_HOME helps suppress winutils warnings if Spark cannot
    # find native hadoop binaries. If SPARK_HOME is set, use it as a hint.
    sp_home = os.environ.get("SPARK_HOME") or config.SPARK_HOME
    if sp_home and not sp_home.startswith("<"):
        os.environ.setdefault("HADOOP_HOME", sp_home)

    logger.info("Using PYSPARK_PYTHON=%s", os.environ.get("PYSPARK_PYTHON"))
    logger.info("JAVA_TOOL_OPTIONS=%s", os.environ.get("JAVA_TOOL_OPTIONS"))
    logger.info("HADOOP_HOME=%s", os.environ.get("HADOOP_HOME"))

    # Init findspark with SPARK_HOME if provided
    sp_home = os.environ.get("SPARK_HOME") or config.SPARK_HOME
    if sp_home and not sp_home.startswith("<"):
        findspark.init(sp_home)
    else:
        findspark.init()

    # Ensure a Hadoop user name is set (helps avoid secure UGI/Subject issues)
    import getpass
    os.environ.setdefault("HADOOP_USER_NAME", os.environ.get("HADOOP_USER_NAME") or getpass.getuser())

    spark = (
        SparkSession.builder.appName("COVID19-Dashboard")
        .master("local[*]")
        .config("spark.ui.enabled", "true")
        .config("spark.ui.port", str(config.SPARK_UI_PORT))
        .config("spark.ui.showConsoleProgress", "true")
        .config("spark.driver.host", "127.0.0.1")
        .config("spark.driver.bindAddress", "127.0.0.1")
        .config("spark.hadoop.hadoop.security.authentication", "simple")
        .config("spark.driver.extraJavaOptions", "-Djavax.security.auth.useSubjectCredsOnly=false")
        .config("spark.executor.extraJavaOptions", "-Djavax.security.auth.useSubjectCredsOnly=false")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")
    logger.info("SparkSession initialized")
    return spark


def _ensure_data_file():
    data_path = Path(config.DATA_FILE)
    data_path.parent.mkdir(parents=True, exist_ok=True)
    url = (
        "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/"
        "csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_global.csv"
    )
    # Download if missing or if the placeholder file is present (small size or placeholder text)
    should_download = False
    if not data_path.exists():
        should_download = True
    else:
        try:
            size = data_path.stat().st_size
            if size < 200:
                should_download = True
            else:
                with data_path.open("r", encoding="utf-8", errors="ignore") as f:
                    first = f.readline()
                    if first.strip().startswith("# Placeholder"):
                        should_download = True
        except Exception:
            should_download = True

    if should_download:
        logger.info("Downloading data to %s", str(data_path))
        urllib.request.urlretrieve(url, str(data_path))
    return str(data_path)


def load_data(spark: SparkSession):
    """Load CSV into Spark DataFrame and register a temp view.

    Returns the DataFrame.
    """
    csv_path = _ensure_data_file()
    df = spark.read.csv(csv_path, header=True, inferSchema=True)
    df.createOrReplaceTempView("covid")
    logger.info("Data loaded with %d rows and %d columns", df.count(), len(df.columns))
    return df


def run_analysis(spark: SparkSession, df):
    """Run SQL/grouping and a simple LinearRegression on aggregated series.

    Returns (top10_spark_df, regression_slope_float)
    """
    # Determine latest date column (last column)
    last_col = df.columns[-1]

    # Top 10 countries by latest total
    top10 = (
        df.groupBy("Country/Region")
        .agg(F.sum(F.col(last_col)).alias("total"))
        .orderBy(F.desc("total"))
        .limit(10)
    )

    # Prepare aggregated time series (sum across all countries per date)
    date_cols = df.columns[4:]
    sum_exprs = [F.sum(F.col(c)).alias(c) for c in date_cols]
    totals_row = df.select(*sum_exprs).limit(1).collect()[0]

    # Build rows (day index, cases)
    rows = []
    for idx, c in enumerate(date_cols):
        cases = totals_row[c]
        try:
            cases = float(cases)
        except Exception:
            cases = 0.0
        rows.append((float(idx), cases))

    series_df = spark.createDataFrame(rows, ["day", "cases"]) .withColumn("day", F.col("day").cast(DoubleType()))

    assembler = VectorAssembler(inputCols=["day"], outputCol="features")
    training = assembler.transform(series_df).select("features", "cases")

    lr = LinearRegression(featuresCol="features", labelCol="cases")
    slope = None
    intercept = None
    r2 = None
    rmse = None
    used_ml = False
    trend_pdf = None

    try:
        model = lr.fit(training)
        slope = float(model.coefficients[0])
        intercept = float(model.intercept)
        used_ml = True
        logger.info("Fitted linear regression slope (PySpark ML): %s", slope)

        # Prepare predictions and evaluate
        preds = model.transform(training)
        preds = preds.withColumn("day", F.col("features").getItem(0)).select("day", "cases", F.col("prediction").alias("predicted"))

        from pyspark.ml.evaluation import RegressionEvaluator

        evaluator_rmse = RegressionEvaluator(labelCol="cases", predictionCol="predicted", metricName="rmse")
        evaluator_r2 = RegressionEvaluator(labelCol="cases", predictionCol="predicted", metricName="r2")

        rmse = float(evaluator_rmse.evaluate(preds))
        r2 = float(evaluator_r2.evaluate(preds))

        trend_pdf = preds.orderBy("day").toPandas()

    except Exception as e:
        logger.warning("PySpark ML fit failed (%s). Falling back to NumPy polyfit.", e)
        # Fallback: compute slope & intercept via NumPy on the small aggregated series
        try:
            import numpy as _np
            import pandas as _pd

            xs = [r[0] for r in rows]
            ys = [r[1] for r in rows]
            coef = _np.polyfit(xs, ys, 1)
            slope = float(coef[0])
            intercept = float(coef[1])
            # compute metrics (simple)
            preds = _np.polyval(coef, xs)
            try:
                ss_res = _np.sum((ys - preds) ** 2)
                ss_tot = _np.sum((ys - _np.mean(ys)) ** 2)
                r2 = float(1 - ss_res / ss_tot) if ss_tot != 0 else 0.0
            except Exception:
                r2 = 0.0
            try:
                rmse = float(_np.sqrt(_np.mean((ys - preds) ** 2)))
            except Exception:
                rmse = 0.0

            trend_pdf = _pd.DataFrame({"day": xs, "cases": ys, "predicted": preds})
            logger.info("Fitted linear regression slope (NumPy fallback): %s", slope)
        except Exception as e2:
            logger.error("Fallback regression also failed: %s", e2)
            slope = 0.0
            intercept = 0.0
            r2 = 0.0
            rmse = 0.0
            import pandas as _pd

            trend_pdf = _pd.DataFrame({"day": [r[0] for r in rows], "cases": [r[1] for r in rows], "predicted": [0.0 for _ in rows]})

    metrics = {"slope": slope, "intercept": intercept, "r2": r2, "rmse": rmse, "used_ml": used_ml}

    return top10, metrics, trend_pdf
