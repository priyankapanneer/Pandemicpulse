"""Configuration placeholders for local development.

Set JAVA_HOME and SPARK_HOME in your environment before running.
Examples are in README.md.
"""
import os

# These are read from the environment; set them in your OS.
# Example (Windows PowerShell):
#   $env:JAVA_HOME = 'C:\Program Files\Java\jdk-11'
#   $env:SPARK_HOME = 'C:\spark'

JAVA_HOME = os.environ.get("JAVA_HOME", "<SET_YOUR_JAVA_HOME>")
SPARK_HOME = os.environ.get("SPARK_HOME", "<SET_YOUR_SPARK_HOME>")

SPARK_UI_PORT = 4050
SPARK_UI_URL = f"http://localhost:{SPARK_UI_PORT}"

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")
DATA_FILE = os.path.join(DATA_DIR, "covid_data.csv")
