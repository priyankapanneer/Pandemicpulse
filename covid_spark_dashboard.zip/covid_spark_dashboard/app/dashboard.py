"""Flask app factory and routes for the COVID dashboard."""
from flask import Flask, render_template
import plotly.graph_objects as go
import networkx as nx
from plotly.offline import plot

from . import config


def create_app(spark_results: dict):
    """Create and configure the Flask app.

    spark_results must contain:
      - top_countries_df (pandas.DataFrame)
      - ml_metrics (dict with slope/intercept/r2/rmse/used_ml)
      - trend_df (pandas.DataFrame) with columns day,cases,predicted
    """
    app = Flask(__name__, static_folder="../static", template_folder="../templates")

    @app.route("/")
    def index():
        top_df = spark_results.get("top_countries_df")
        ml_metrics = spark_results.get("ml_metrics", {})
        trend_df = spark_results.get("trend_df")

        slope = ml_metrics.get("slope")
        intercept = ml_metrics.get("intercept")
        r2 = ml_metrics.get("r2")
        rmse = ml_metrics.get("rmse")
        used_ml = ml_metrics.get("used_ml", False)

        # Top country summary
        top_country = None
        top_total = None
        if not top_df.empty:
            top_country = top_df.iloc[0]["Country/Region"]
            top_total = int(top_df.iloc[0]["total"])

        # Table HTML
        table_html = top_df.to_html(classes="table table-striped table-sm", index=False, border=0, justify='center')

        # Network graph: fully connected graph of top countries
        countries = list(top_df["Country/Region"])
        G = nx.complete_graph(len(countries))
        mapping = {i: countries[i] for i in range(len(countries))}
        G = nx.relabel_nodes(G, mapping)
        pos = nx.spring_layout(G, seed=42)

        edge_x = []
        edge_y = []
        for e in G.edges():
            x0, y0 = pos[e[0]]
            x1, y1 = pos[e[1]]
            edge_x += [x0, x1, None]
            edge_y += [y0, y1, None]

        edge_trace = go.Scatter(x=edge_x, y=edge_y, line=dict(width=0.5, color="#888"), hoverinfo='none', mode='lines')

        node_x = []
        node_y = []
        node_text = []
        for n in G.nodes():
            x, y = pos[n]
            node_x.append(x)
            node_y.append(y)
            node_text.append(n)

        node_trace = go.Scatter(
            x=node_x,
            y=node_y,
            mode='markers+text',
            hoverinfo='text',
            text=node_text,
            marker=dict(size=20, color='skyblue')
        )

        fig = go.Figure(data=[edge_trace, node_trace])
        fig.update_layout(showlegend=False, margin=dict(l=20, r=20, t=20, b=20), xaxis=dict(showgrid=False, zeroline=False, showticklabels=False), yaxis=dict(showgrid=False, zeroline=False, showticklabels=False))

        plot_div = plot(fig, output_type='div', include_plotlyjs=False)
        # Bar chart for top countries
        bar_fig = go.Figure(
            data=[go.Bar(x=top_df['Country/Region'], y=top_df['total'], marker_color='indianred')]
        )
        bar_fig.update_layout(margin=dict(l=20, r=20, t=30, b=20), height=320, title_text='Top 10 Countries by Total Cases')
        bar_plot = plot(bar_fig, output_type='div', include_plotlyjs=False)

        # Time series + regression line
        ts_plot = ""
        if trend_df is not None:
            try:
                df_ts = trend_df.copy()
                ts_fig = go.Figure()
                ts_fig.add_trace(go.Scatter(x=df_ts['day'], y=df_ts['cases'], mode='markers', name='Actual', marker=dict(color='#4f7bd6')))
                ts_fig.add_trace(go.Scatter(x=df_ts['day'], y=df_ts['predicted'], name='Model', line=dict(color='#ff7b6b')))
                ts_fig.update_layout(title='Aggregated cases & fitted trend', height=360, margin=dict(l=20, r=20, t=30, b=20))
                ts_plot = plot(ts_fig, output_type='div', include_plotlyjs=False)
            except Exception:
                ts_plot = ""

        return render_template(
            "index.html",
            top_country=top_country,
            top_total=top_total,
            regression_slope=slope,
            intercept=intercept,
            r2=r2,
            rmse=rmse,
            used_ml=used_ml,
            table_html=table_html,
            network_plot=plot_div,
            bar_plot=bar_plot,
            ts_plot=ts_plot,
            spark_ui_url=config.SPARK_UI_URL,
        )

    return app
