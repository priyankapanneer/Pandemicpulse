"""Entry point: initialize Spark, run analysis, and start Flask dashboard."""
import threading
import webbrowser
import time

from app.spark_job import setup_spark, load_data, run_analysis
from app.dashboard import create_app


def _open_urls():
    # Give server a moment to start
    time.sleep(1.0)
    webbrowser.open("http://127.0.0.1:5000")
    webbrowser.open("http://127.0.0.1:4050")


def main():
    spark = setup_spark()
    df = load_data(spark)
    top10_df, ml_metrics, trend_pdf = run_analysis(spark, df)

    # Convert to pandas for Flask layer
    top10_pdf = top10_df.toPandas()

    spark_results = {"top_countries_df": top10_pdf, "ml_metrics": ml_metrics, "trend_df": trend_pdf}

    app = create_app(spark_results)

    # Open the dashboard and Spark UI in the default browser shortly after start
    threading.Thread(target=_open_urls, daemon=True).start()

    try:
        app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False)
    except KeyboardInterrupt:
        print("Shutting down...")


if __name__ == "__main__":
    main()
