"""Provides a LooseVersion class compatible with distutils.version.LooseVersion.

This is a small shim so code that does `from distutils.version import LooseVersion`
continues to work on Python versions where distutils is removed.
"""
from packaging.version import Version


class LooseVersion:
    def __init__(self, v):
        self._v = Version(str(v))

    def __lt__(self, other):
        return self._v < Version(str(other))

    def __le__(self, other):
        return self._v <= Version(str(other))

    def __gt__(self, other):
        return self._v > Version(str(other))

    def __ge__(self, other):
        return self._v >= Version(str(other))

    def __str__(self):
        return str(self._v)
