"""Minimal shim for distutils to satisfy imports in third-party libraries.

This provides a `version.LooseVersion` compatible wrapper using `packaging`.
"""
from . import version
