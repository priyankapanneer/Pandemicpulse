# COVID-19 Spark + Flask Dashboard

This project runs a local PySpark job (with Spark Web UI) and serves a Flask dashboard.

Quickstart

1. Create and activate a virtualenv

Windows (PowerShell):

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Linux / macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

2. Install dependencies

```bash
pip install -r requirements.txt
```

3. Set Java and Spark environment variables (examples)

Windows (PowerShell):

```powershell
$env:JAVA_HOME = 'C:\Program Files\Java\jdk-11'
$env:SPARK_HOME = 'C:\spark'
```

Linux / macOS:

```bash
export JAVA_HOME="/usr/lib/jvm/java-11-openjdk"
export SPARK_HOME="/opt/spark"
```

4. Run the app

```bash
python main.py
```

Where to see:

- Dashboard: http://localhost:5000
- Spark UI: http://localhost:4050
